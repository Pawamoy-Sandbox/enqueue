#ifndef __BASE_H
#define __BASE_H

#include <stdio.h>
#include <stdlib.h>

typedef enum {false, true} Bool;

#endif // __BASE_H
